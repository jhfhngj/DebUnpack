import os
#Deb Unpack
print("Deb Unpack")
#Path
path = input("For the command, what is the folder path? You do not have to include '/home/'. ")
#Name of file
name = input("Tell us the name of the file, no need for '.deb'. ")
#apt or dpkg
typec = input("APT or DPKG? ")
#If apt
if typec == "apt":
    print("OK. Installing by APT.")
    os.system("sudo apt install /home/" + path + name + ".deb")
#If dpkg
if typec == "dpkg":
    print("Installing from DPKG.")
    os.system("sudo dpkg -i /home/" + path + name)
    os.system("sudo apt-get install -f")